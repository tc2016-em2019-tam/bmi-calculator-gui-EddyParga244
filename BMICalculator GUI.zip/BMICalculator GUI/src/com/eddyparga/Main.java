package com.eddyparga;

import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Ventana ventana = new Ventana();

    }

}
